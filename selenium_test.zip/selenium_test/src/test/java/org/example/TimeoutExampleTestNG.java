package org.example;

public class TimeoutExampleTestNG {
}
