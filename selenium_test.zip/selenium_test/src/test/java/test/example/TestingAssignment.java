package test.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import java.time.Duration;

import static org.testng.AssertJUnit.assertEquals;

public class TestingAssignment {

    public static WebDriverWait myWait;
    static WebDriver driver;
    WebElement username;
    WebElement password;

    @BeforeClass
    void setUp() throws InterruptedException {
        driver = new EdgeDriver();
        driver.get("http://127.0.0.1:5500/index.html");
        myWait = new WebDriverWait(driver, Duration.ofSeconds(3100));
    }


    @Test
    void login() throws InterruptedException {
        // 等待登录链接变得可点击并点击它
        WebElement loginLink = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"login\"]")));
        loginLink.click();
        Thread.sleep(2000);

        WebElement usernameField = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        usernameField.sendKeys("user");
        Thread.sleep(2000);

        WebElement passwordField = myWait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
       passwordField.sendKeys("password");
        Thread.sleep(2000);

        WebElement LoginButton = myWait.until(ExpectedConditions.elementToBeClickable(By.id("login")));
        LoginButton.click();

    }

    @Test
    void Register() throws InterruptedException {
        myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"register\"]"))).click();
        // 设置等待时间最长为10秒
        WebElement username = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        username.sendKeys("Keith");
        Thread.sleep(2000);


        WebElement email = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
        email.sendKeys("sizhuo.xu@outlook.com");
        Thread.sleep(2000);


        WebElement password = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        password.sendKeys("sizhuo.xu@outlook.com");
        Thread.sleep(2000);

        Select gender = new Select(driver.findElement(By.id("gender")));
        gender.selectByVisibleText("Male");
        Thread.sleep(3000);
        gender.selectByVisibleText("Female");
        Thread.sleep(3000);
        gender.selectByVisibleText("Secret");
        Thread.sleep(3000);

        WebElement phone = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("phone")));
        phone.sendKeys("18011765670");

        // 定位日期输入框，假设它的name属性是'dateInput'
        WebElement birthdayField = driver.findElement(By.id("birthday"));
        String Value1 = "03/02/2021"; // 你想选择的日期
        birthdayField.sendKeys(Value1);
        Thread.sleep(3000);

        String Value2 = "03/02/2022"; // 你想选择的日期
        birthdayField.sendKeys(Value2);
        Thread.sleep(3000);

        String Value3 = "03/02/2023"; // 你想选择的日期
        birthdayField.sendKeys(Value3);
        Thread.sleep(3000);

        String Value4 = "03/02/2000"; // 你想选择的日期
        birthdayField.sendKeys(Value4);
        Thread.sleep(3000);

        String Value5 = "03/02/2010"; // 你想选择的日期
        birthdayField.sendKeys(Value5);
        Thread.sleep(3000);
    }

    @Test
    void  management() throws InterruptedException {
        myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"management\"]"))).click();
        Thread.sleep(2000);


        WebElement loginLink = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"add \"]")));
        loginLink.click();
        WebElement editName = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("editName")));

        editName.sendKeys("Iris");

        Select editGender = new Select(driver.findElement(By.id("editGender")));
        editGender.selectByVisibleText("male");
        Thread.sleep(3000);
        editGender.selectByVisibleText("female");
        Thread.sleep(3000);


        //这里有两处错误，一处失误发现
        //如果是自动化输入日期，这里的年份显示会出现显示错误。所以我们的解决方法是多加一个clear语句
        //我们在这里可以发现，如果我们改变了birthd的id，则会抛出异常，按钮失效
        //加入clear后，有可能会导致文本自动消失，我们可以加上sleep延迟避免这个错误
        WebElement birthdayField = driver.findElement(By.id("birthday"));
        String Value6 = "03/02/2021"; // 你想选择的日期
        birthdayField.sendKeys(Value6);
        Thread.sleep(3000);

        birthdayField.clear();


        String Value7 = "03/02/2002"; // 你想选择的日期
        birthdayField.sendKeys(Value7);
        Thread.sleep(3000);
        birthdayField.clear();


        String Value8 = "03/02/2001"; // 你想选择的日期
        birthdayField.sendKeys(Value8);
        Thread.sleep(3000);
        birthdayField.clear();


        String Value9 = "03/02/2003"; // 你想选择的日期
        birthdayField.sendKeys(Value9);
        Thread.sleep(3000);
        birthdayField.clear();


        String Value10 = "03/02/2008"; // 你想选择的日期
        birthdayField.sendKeys(Value10);
        Thread.sleep(2000);


        WebElement editPhone = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("editPhone")));
        editPhone.sendKeys("18011765670");

        myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"saveButton\"]"))).click();
        //这里如果加上了睡眠的语句，则最后的save的按钮则会消失

        //myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id="cancle"]"))).click();
        //如果我们选择取消信息增加，我们可以恢复这段语句

        myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"studentTable\"]/tr[1]/td[1]/input"))).click();
        myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"delete\"]"))).click();


    }
        @Test
        public void testDeleteSelectedStudentsSequentiallyWithConfirm() throws InterruptedException {
            myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"management\"]"))).click();
            Thread.sleep(2000);


            WebElement loginLink = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"add \"]")));
            loginLink.click();
            WebElement editName = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("editName")));

            editName.sendKeys("Iris");

            Select editGender = new Select(driver.findElement(By.id("editGender")));
            editGender.selectByVisibleText("male");
            Thread.sleep(3000);
            editGender.selectByVisibleText("female");
            Thread.sleep(3000);


            //这里有两处错误，一处失误发现
            //如果是自动化输入日期，这里的年份显示会出现显示错误。所以我们的解决方法是多加一个clear语句
            //我们在这里可以发现，如果我们改变了birthd的id，则会抛出异常，按钮失效
            //加入clear后，有可能会导致文本自动消失，我们可以加上sleep延迟避免这个错误
            WebElement birthdayField = driver.findElement(By.id("birthday"));
            String Value6 = "03/02/2021"; // 你想选择的日期
            birthdayField.sendKeys(Value6);
            Thread.sleep(3000);

            birthdayField.clear();


            String Value7 = "03/02/2002"; // 你想选择的日期
            birthdayField.sendKeys(Value7);
            Thread.sleep(3000);
            birthdayField.clear();


            String Value8 = "03/02/2001"; // 你想选择的日期
            birthdayField.sendKeys(Value8);
            Thread.sleep(3000);
            birthdayField.clear();


            String Value9 = "03/02/2003"; // 你想选择的日期
            birthdayField.sendKeys(Value9);
            Thread.sleep(3000);
            birthdayField.clear();


            String Value10 = "03/02/2008"; // 你想选择的日期
            birthdayField.sendKeys(Value10);
            Thread.sleep(2000);


            WebElement editPhone = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("editPhone")));
            editPhone.sendKeys("18011765670");

            myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"saveButton\"]"))).click();
            //这里如果加上了睡眠的语句，则最后的save的按钮则会消失

            //myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id="cancle"]"))).click();
            //如果我们选择取消信息增加，我们可以恢复这段语句

            myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"studentTable\"]/tr[1]/td[1]/input"))).click();

            myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"delete\"]"))).click();


            // 模拟点击删除按钮
            Alert alert = driver.switchTo().alert();
            String expectedMessage = "Are you sure you want to delete the following student information?"; // 替换为实际的确认消息
            assertEquals(expectedMessage, alert.getText());
            alert.accept();

            // 验证删除操作是否成功，例如检查学生列表是否为空










        // Assert
        //ddt
    }

    //@AfterClass
    //public static void tearDown() {
       /// if (driver != null) {
            //driver.quit();
        }
   // }
//}

