module org.example.selenium_test {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.selenium_test to javafx.fxml;
    exports org.example.selenium_test;
}